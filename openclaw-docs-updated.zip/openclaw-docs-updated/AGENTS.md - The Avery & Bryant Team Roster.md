# AGENTS.md - The Avery & Bryant Team Roster

> **For the Orchestrator's eyes only.** Do NOT pass this file to sub-agents. Each sub-agent receives only its own task description, credentials, and skill reference.

---

## How to Use This Roster

When a task arrives, follow this process:

1. **Identify** which Engine (A-E) the task belongs to.
2. **Select** the corresponding sub-agent from the table below.
3. **Spawn** the sub-agent using the `agent` tool. Provide it with:
   - A clear, one-sentence task description.
   - The **Skill Reference** file path so it knows its SOP.
   - The **Credentials** it needs (and nothing else).
   - The instruction: *"When complete, return your findings as a structured summary."*
4. **Synthesize** the sub-agent's output into the Daily Pulse or the relevant report for Thomas.

---

## Agent Roster

| # | Agent Name | Engine | Skill Reference | Model Tier | Primary Function |
|---|---|---|---|---|---|
| 1 | **The Analyst** | D (Ops) | `skills/ops-revenue-tracker/SKILL.md` | Tier 2 | Revenue tracking, KPI calculation, Daily Pulse data. |
| 2 | **The Coordinator** | B (Production) | `skills/production-manager/SKILL.md` | Tier 2 | Shoot scheduling, task monitoring, Red Flag identification. |
| 3 | **The Copywriter** | C (Growth) | `skills/client-growth-nurture/SKILL.md` | Tier 2 | Follow-ups, review requests, upsell messaging. |
| 4 | **The Strategist** | E (Expansion) | `skills/business-expansion/SKILL.md` | Tier 1 | Revenue goal alignment, new stream ideation, canvas updates. |
| 5 | **The Scout** | A (Lead Capture) | `skills/lead-capture-pro/SKILL.md` | Tier 2 | Lead qualification, booking, and intake automation. |
| 6 | **The Marketer** | C (Growth) | `skills/email-marketing/SKILL.md` | Tier 2 | Email campaigns, drip sequences, SMS outreach, newsletters. |
| 7 | **The Designer** | C (Growth) + E | `skills/creative-designer/SKILL.md` | Tier 2 | Social media graphics, listing flyers, brand assets. |
| 8 | **The Bookkeeper** | D (Ops) | `skills/bookkeeper/SKILL.md` | Tier 2 | Stripe reconciliation, invoices, revenue reporting. |

---

## Agent Details

### 1. THE ANALYST (Engine D - Ops & Revenue)

**When to spawn**: Daily Pulse checks, revenue questions, KPI requests, financial reporting.

**Credentials to provide**:

| Service | Key | Value |
|---|---|---|
| GoHighLevel | API Token | `pit-db7a30ee-5edd-47dc-bb20-8bfdf712c19d` |
| GoHighLevel | Location ID | `iXhH37718q9nZnf4tkgF` |
| GoHighLevel | API Base URL | `https://services.leadconnectorhq.com` |
| GoHighLevel | API Version Header | `Version: 2021-07-28` |

**API Endpoints**:
- Search Opportunities: `GET /opportunities/search?location_id={location_id}&status=all`
- Get Pipelines: `GET /opportunities/pipelines?locationId={location_id}`

**Report-back format**: Return a structured summary with: total new opportunities, total revenue value, and any notable pipeline changes.

---

### 2. THE COORDINATOR (Engine B - Production)

**When to spawn**: Red Flag checks, shoot prep verification, turnaround time monitoring, task status updates.

**Credentials to provide**:

| Service | Key | Value |
|---|---|---|
| ClickUp | API Token | `pk_57024972_OLWKESF03QXRFR73FPFEI398QODAXBKM` |
| ClickUp | Team ID | `31553962` |
| ClickUp | API Base URL | `https://api.clickup.com/api/v2` |
| ClickUp | Client ID | `YS2KOUH5BERHQD05P12QWPYYQTKOAWIL` |
| ClickUp | Client Secret | `55O7O2BCC9ODLTIG73SGU87YH940UW5Z77DE5DP46W3GP9R12RLMWLVH9PIZPSVW` |

**API Endpoints**:
- Get Tasks: `GET /team/{team_id}/task?include_closed=false&subtasks=true`
- Get Spaces: `GET /team/{team_id}/space`

**Red Flag Criteria**: Tasks with status "Needs Revision", "Stuck", "Blocked", or any task past its due date.

**Report-back format**: Return a list of Red Flag tasks with: task name, status, due date, assignee, and a direct ClickUp link.

---

### 3. THE COPYWRITER (Engine C - Growth & Nurture)

**When to spawn**: Post-delivery follow-ups, review requests, upsell campaigns, newsletter drafts, client communication.

**Credentials to provide**: None required at this time. Future integrations (Gmail, Mailchimp) will be added here.

**Communication guidelines**: Professional, appreciative tone. Always personalize with the property address. Highlight how the media helps the listing stand out.

**Report-back format**: Return the draft message(s) with: recipient name, channel (email/SMS), subject line, and body text for Thomas's approval.

---

### 4. THE STRATEGIST (Engine E - Expansion)

**When to spawn**: Weekly business reviews, revenue target analysis, new service ideation, operational canvas updates.

**Credentials to provide**: None required. Uses data synthesized from The Analyst and The Coordinator.

**Canvas Context**: When spawning The Strategist, always provide the relevant sections of `CANVAS.md`. Key sections include:
- **Section 10 (Execution Order)**: Current phase and next steps.
- **Sections R.1–R.11**: The 12-month revenue acceleration plan, AOV targets, retainer strategy, and volume scaling math.
- **Section K.1–K.6**: KPI definitions and targets.
- **Section H.1–H.6**: Hiring roadmap and org structure.
- **Engine E (E.1–E.6)**: Expansion architecture including studio, digital products, subscriptions, partnerships, and multi-city scaling.

**Report-back format**: Return a strategic brief with: current revenue vs. target, identified opportunities, recommended next actions, and which Canvas phase to focus on next.

---

### 5. THE SCOUT (Engine A - Lead Capture)

**When to spawn**: New inquiry processing, lead qualification, booking confirmation.

**Credentials to provide**: Same as The Analyst (GoHighLevel) for CRM updates.

| Service | Key | Value |
|---|---|---|
| GoHighLevel | API Token | `pit-db7a30ee-5edd-47dc-bb20-8bfdf712c19d` |
| GoHighLevel | Location ID | `iXhH37718q9nZnf4tkgF` |

**Report-back format**: Return lead status with: contact name, property address, services requested, qualification result (Qualified/Unqualified), and next action taken.

---

### 6. THE MARKETER (Engine C - Growth & Outreach)

**When to spawn**: Email campaigns, drip sequences, SMS outreach, review request flows, reactivation campaigns, newsletter content, Top-20 agent touches.

**Credentials to provide**: Same as The Analyst (GoHighLevel) for CRM segmentation and contact data.

| Service | Key | Value |
|---|---|---|
| GoHighLevel | API Token | `pit-db7a30ee-5edd-47dc-bb20-8bfdf712c19d` |
| GoHighLevel | Location ID | `iXhH37718q9nZnf4tkgF` |

**Canvas Context**: Key sections to provide:
- **C.1-C.5**: Post-delivery automation, review flywheel, repeat booking nurture, upsell paths, referral system.
- **R.10.7.4**: 14-day follow-up sequence for non-closing branding prospects.
- **R.11.8.2-R.11.8.3**: Weekly Top-20 agent touch cadence and reactivation workflow.

**Report-back format**: Return all drafts with: campaign name, audience segment, channel (email/SMS), subject line, body text, CTA, and send timing. All drafts require Thomas's approval.

---

### 7. THE DESIGNER (Engine C + E - Creative & Brand)

**When to spawn**: Social media graphics, listing flyers, agent branding assets, promotional materials, pitch decks, studio marketing, digital product visuals.

**Credentials to provide**: None required at this time. Works with files and briefs provided by the Orchestrator.

**Canvas Context**: Key sections to provide:
- **R.9.6**: Package tier structure (Essentials, Marketing, Cinematic) for listing flyer templates.
- **R.10.2**: Retainer tier structure (Starter, Growth, Authority) for branding asset packages.
- **E.1**: Studio marketing materials.
- **E.2**: Digital product and course visuals.

**Report-back format**: Return all designs with: asset name, dimensions/format, intended platform, caption (if social), and file attachment. All designs require Thomas's approval.

---

### 8. THE BOOKKEEPER (Engine D - Financial Ops)

**When to spawn**: Daily payment reconciliation, outstanding invoice tracking, weekly revenue reports, per-shoot profitability analysis, retainer billing monitoring, revenue forecasting.

**Credentials to provide**:

| Service | Key | Value |
|---|---|---|
| Stripe | Secret Key | Use `STRIPE_SECRET_KEY` environment variable |
| GoHighLevel | API Token | `pit-db7a30ee-5edd-47dc-bb20-8bfdf712c19d` |
| GoHighLevel | Location ID | `iXhH37718q9nZnf4tkgF` |

**Data Files**: `stripe_history.csv` in workspace contains historical payment data.

**Canvas Context**: Key sections to provide:
- **K.1**: Revenue visibility (today, week, month, YTD).
- **K.2**: Per-shoot profitability metrics.
- **R.1**: $750k target = $62,500/month = ~$14,400/week.
- **R.10.5**: Retainer MRR target of $15k-$20k/month.

**Report-back format**: Return financial reports with: period covered, total revenue, transaction count, AOV, comparison to target, and flagged items. All amounts in USD.

---

## Adding New Agents (Future-Proofing)

To add a new specialist:

1. Create a new skill directory: `skills/{skill-name}/SKILL.md`
2. Add a new section to this file following the template above.
3. Include the Engine mapping, credentials, API endpoints, and report-back format.
4. The Orchestrator will automatically recognize the new agent on its next heartbeat.
