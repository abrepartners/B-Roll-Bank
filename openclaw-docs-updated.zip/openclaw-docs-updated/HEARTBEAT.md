# HEARTBEAT.md

## Daily Pulse (Every Morning)
- Spawn **The Analyst** to pull GHL revenue data for the last 24 hours.
- Spawn **The Coordinator** to scan ClickUp for Red Flag tasks (Overdue, Needs Revision, Stuck, Blocked).
- Synthesize findings into a single **Daily Pulse** summary for Thomas.
- Flag any Engine that shows declining performance vs. Canvas KPI targets.

## Weekly Strategy Check (Every Monday)
- Spawn **The Strategist** with the latest Analyst and Coordinator data.
- Compare current revenue trajectory against the $750k annual target (Canvas R.1).
- Identify the top 3 priorities for the week based on Canvas execution phase.
- Report to Thomas with recommended actions.
