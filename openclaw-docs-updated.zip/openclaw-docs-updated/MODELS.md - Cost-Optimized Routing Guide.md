# MODELS.md - Cost-Optimized Routing Guide

This guide defines the model tiering strategy for Avery & Bryant to ensure maximum performance at the lowest possible cost.

## Model Tiers

| Tier | Model Category | Recommended Models | Use Case |
| :--- | :--- | :--- | :--- |
| **Tier 1** | **Frontier** | GPT-4o, Claude 3.5 Sonnet | Main Orchestrator, complex strategy, architecture decisions, multi-file refactoring. |
| **Tier 2** | **Mid-Tier** | GPT-4o-mini, Gemini 1.5 Flash | Sub-agents, daily research, content drafting, data processing. |
| **Tier 3** | **Cheap** | GPT-4o-mini, Gemini 1.5 Flash | Heartbeat checks, simple classification, status lookups, logging. |

## Routing Rules

1. **Heartbeats**: ALWAYS use Tier 3 models. These checks are frequent and do not require high intelligence.
2. **Sub-Agents**: Default to Tier 2 models. Only escalate to Tier 1 if the sub-agent is performing complex reasoning or coding.
3. **Main Agent**: Use Tier 1 for the initial analysis of Thomas's requests and for synthesizing final reports.
4. **Fallback**: If a Tier 1 model hits a rate limit, fall back to a Tier 2 model from a different provider (e.g., if OpenAI is down, use Gemini).

## Cost Efficiency Target
- **Goal**: Reduce API costs by 50-80% by routing 90% of background tasks to Tier 2/3 models.
- **Monitoring**: The Orchestrator should periodically report on token usage and cost savings in the weekly strategy review.
